from .color import (
    color_text_cleangreen,
    color_text_yellow_gradient,
    color_text_grey_gradient,
    color_text_purple_night,
    color_text_frozen_blue,
    color_text_pastel_rainbow,
    color_text_infrared_red,
    color_text_toxic_green,
    color_text_cappuccino,
    color_text_minty_fresh,
)
