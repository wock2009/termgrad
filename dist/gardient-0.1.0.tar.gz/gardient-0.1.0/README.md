# Package name > Gardient
# Made by > wock2009
# Site > https://coderhangout.xyz

# Why choose gradient? > Gardient package is a clean and colourful package.
For your terminal tools. Its easy to apply onto your CLI tools.
Gardient package got many cool colors.